<?php
/**
 * Author: SIR DAVEMATICS
 * Assignment: PHP Mail sending with php mailer
 * Created by atom.
 * Date: 6/11/2018
 * Time: 9:09 AM
 */


require_once 'db_config.php';

class db_class extends db_connect{

		public function __construct(){
			$this->connect();
		}







    function send_mail($email,$message,$subject)  //all the mail settings for verification emails
    {
        require 'mailer/PHPMailerAutoload.php';
        $mail = new PHPMailer(); //create a new object
        $mail->IsSMTP(); //enable SMTP
        $mail->SMTPDebug  =0; //debugging: 1 errors and messages, 2 messages only. Made 0 for production
        $mail->SMTPAuth   = true; //authentication enabled
        $mail->SMTPSecure = "ssl"; //secure transfer enabled required for gmail
        $mail->Host       = "smtp.gmail.com";
        $mail->Port       = 465; //or try 587
        $mail->IsHTML(true);
        $mail->AddAddress($email);
        $mail->Username="naijatechub@gmail.com";
        $mail->Password="PASSWORD";
        $mail->SetFrom('naijatechub@gmail.com','Global Green');
        $mail->AddReplyTo("davgwuche@gmail.com","Global Green");
        $mail->Subject    = $subject;
        $mail->MsgHTML($message);
        $mail->Send();


    }
}
