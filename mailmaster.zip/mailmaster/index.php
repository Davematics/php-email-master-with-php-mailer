
<?php
require_once 'class.user.php';
session_start();
$msg="";
if(isset($_POST['submit'])) /*if the signup button is clicked, go through the selection structure below*/
{
	$conn = new db_class();
    include_once('mailer/class.phpmailer.php');

    require_once('mailer/class.smtp.php');
    extract($_POST);



						$conn->send_mail($email,$message,$subject);
						echo '
				      <script>alert("Message Sent")</script>;

				    ';

}
?>


<!DOCTYPE html>
<html>
<head>
<title>Mail Master</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
</br></br>
<!-- /Banner-->


<!-- News-->
</br></br>
<!--/News-->



			</div>





<?php echo $msg;?>
<div class="container">
  <h2>Send Mail Master By Davematics</h2>
<form name="registration" action="" method="post">
	<div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>

		<div class="form-group">
				<label for="email">Subject:</label>
				<input type="email" class="form-control" id="email" placeholder="enter subject" name="subject">
			</div>
	<div class="col-12 ">
	<label for="files" class="btn">Type Message</label>
	<textarea name="message" cols="" rows="" class="form-control form-control-lg"></textarea>
</div><br/><br/>
<input type="submit" name="submit" value="Send" class="btn btn-default"/>
</form>


			</div>
		   </div>
		  </div>
			 		  <section id="tables">


	</div>
</div>


	</div>
</div>

	<!-- footer-section -->

	<!-- footer-section -->
	<script type="text/javascript">
		$(document).ready(function() {
				/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
				};
				*/
		$().UItoTop({ easingType: 'easeOutQuart' });
});
</script>
<a href="#to-top" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!---->


</body>
</html>
